// try{
let GET = require('./GET');
let POST = require('./POST');
let PUT = require('./PUT');
let DELETE = require('./DELETE');
let OPTIONS = require('./OPTIONS');
let DUMP = require('./DUMP');
// }catch(e){console.log(e);}
/**
 * Main field where we will fetch all the content and passer
 * @param  {[type]}   event    [description]
 * @param  {[type]}   context  [description]
 * @param  {Function} callback [description]
 * @return {[type]}            [description]
 */
exports.handler = function(event,context,callback) {
	setInterval(function(){}, 1000);
	context.callbackWaitsForEmptyEventLoop = false;
	switch(event.httpMethod){
		case 'GET': GET.execute({"query":event.queryStringParameters,"headers":event.headers},callback);
					break;
		case 'POST': POST.execute({"body":event.body,"headers":event.headers},callback);
					break;
		case 'PUT': PUT.execute({"body":event.body,"headers":event.headers},callback);
					break;
		case 'DELETE': DELETE.execute({"body":event.body,"headers":event.headers},callback);
					break;
		case 'PATCH':
		case 'OPTIONS': OPTIONS.execute({"body":event.body,"headers":event.headers},callback);
					break;
		default : DUMP.execute(event,callback);
	}
}