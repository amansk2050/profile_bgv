///// ...................................... start default setup ............................................////
let mode,sns,dynamodb,docClient,S3,neo4j;
const AWS 		= require('aws-sdk');
const response 	= require('./lib/response.js');
const database 	= require('./lib/database.js');

if(process.env.AWS_REGION == "local"){
	mode 			= "offline";
	sns 			= require('../../../offline/sns');
	neo4j			= require('../../../offline/Neo4j');
	docClient 		= require('../../../offline/dynamodb').docClient;
	S3 				= require('../../../offline/S3');
	mysql_conf  = require('../../../offline/mysql').Mysql["dev-conf"];
	// dynamodb = require('../../../offline/dynamodb').dynamodb;
}else{
	mode 			= "online";
	sns 			= new AWS.SNS();
	docClient 		= new AWS.DynamoDB.DocumentClient({});
	S3 				= new AWS.S3();
	neo4j 			= require('./lib/neo4j');
	mysql_conf  = database.Mysql["prod-conf"];
	// dynamodb = new AWS.DynamoDB();
}
///// ........................................mysql setup..................................................////

const mysql      = require('mysql');
var mysql_connection;
// if(typeof mysql_connection === 'undefined') {
// 	mysql_connection = mysql.createConnection({
// 		host            : mysql_conf.host,
// 		user            : mysql_conf.user,
// 		password        : mysql_conf.password,
// 		database        : mysql_conf.database
// 	});
// }

///// ...................................... end default setup ............................................////

//modules defined here
const uuid 					= require('uuid');
//call another lambda
// const execute_lambda = require('./lib/lambda')('sample2');
const Ajv 					= require('ajv');
const setupAsync 			= require('ajv-async');
const ajv 					= setupAsync(new Ajv);
const authorization 		= require("./lib/authorization.js");
const fileType      		= require('file-type');

const validate_db_query 	= require('./helper/model_validator.js');
const CHECK 				= require('./helper/CHECK.js')(neo4j);
const ADD 					= require('./helper/ADD.js')(neo4j,mysql_connection);
const RUN 					= require('./helper/RUN.js')(neo4j,mysql_connection);
const LockRefresh 			= require('./lib/LockRefresh.js');

const putSchema = {
  	"$async":true,
  	"type":"object",
  	"required":["model","value"],
  	"properties":{
		"model":{"type":"string"},
		"value":{"type":"object"},
		"related":{
			"type":"object",
			"required":["model","value"],
			"properties":{
				"model":{"type":"string"},
				"value":{"type":"object"}
			}
		},
		"insertRelated":{
			"type":"boolean"
		}
  	}
};

const validate = ajv.compile(putSchema);

/**
 * This is the Promise caller which will call each and every function based
 * @param  {[type]}   data     [content to manipulate the data]
 * @param  {Function} callback [need to send response with]
 * @return {[type]}            [description]
 */
function execute(data,callback){
	/**mysql queue resolved */
	if(typeof mysql_connection === 'undefined') {
        console.log(mysql_conf);
        mysql_connection = mysql.createConnection({
            host            : mysql_conf.host,
            user            : mysql_conf.user,
            password        : mysql_conf.password,
            database        : mysql_conf.database
        });
	}
	
	if(typeof data.body == "string"){
		data.body = JSON.parse(data.body);
	}
	let body = data.body;
	let headers = data.headers;
	validate_all(validate,body)
		.then(function(result){
			return authorization(headers.Authorization,result);
		})
		.then(function(result){
			/** if value some base64 text present then switch it to the url */
			if(result.model == "User" || result.model == "LockGroup" || result.model == "Lock"){
				if(result.value.file){
					return fileS3Uplaod(result);
				}else{
					return result;
				}
			}else{
				return result;
			}
		})
		.then(function(result){
			/** check to insert in the model Permission */
			return check_Permission_validation(result);
		})
		.then(function(result){
			return CHECK(result.Db_values,result);
		})
		.then(function(result){
			console.log("===>");
			console.log(result);
			return DB_operation(result);
		})
		.then(function(result){
			console.log(result);
			response({code:200,body:result},callback);
		})
		.catch(function(err){
			console.log(err);
			if(err.message){
				err = err.message;
			};
			response({code:400,err:{err}},callback);
		})
}

/**
 * validate the data to the categories
 * @param  {[type]} data [description]
 * @return {[type]}      [description]
 */
function validate_all (validate,data) {
	return new Promise((resolve,reject)=>{
		validate(data).then(function (res) {
			console.log(res);
		    resolve(res);
		}).catch(function(err){
		  console.log(JSON.stringify( err,null,6) );
		  reject(err.errors[0].dataPath+" "+err.errors[0].message);
		})
	})
}

/**
 * check Permission
 * @param {*} data 
 */
function check_Permission_validation(data){
	return new Promise((resolve,reject)=>{
		/** convert header to username */
		let Db_values={};
		if(data.related !== undefined){
			/**Permission check
			 * 1. create the other edge Permission
			 * 2. create user Permission
			 */
			if(data.related.model !== undefined && data.related.value !== undefined){
				Db_values={
					"UserName": data.username,
					"levelid":"Permissions",
					"levelName":"A:"+data.related.model,
					"level2id":"Permissions",
					"level2Name":"A:"+data.model
				};
				data['Db_values']=Db_values;
				resolve(data);
			}else{
				reject("Nothing to check"); 
			}
		}else{
			//add only model and values check for the schema for validation
			if(data.model){
				Db_values={
					"UserName":data.username,
					"levelid":"Permissions",
					"levelName":"C:"+data.model
				};
				data['Db_values']=Db_values;
				resolve(data);
			}else{
				reject("Permission check failed");
			}
		}
	})
}

/**
 * Db Operation
 * @param [{type}] data
 */
function DB_operation(data){
	return new Promise((resolve,reject)=>{
		let username = "u1";
		if(data.allow == 1){
			/**format the data into a type of data to create */
			/**
			 * code sample format
			 * {
			 * 	"model":"Company",
			 * 	"edge":"Projects",
			 * 	"data_model":{
			 * 		"Name":"asd",
			 * 		"CreatedAt":"pro"
			 * 	},
			 * 	"data_relation":{
			 * 		"blah":"asd"
			 * },
			 * "data_edge":{
			 * "some":"asd"
			 * }
			 */
			let code = {
				"model":data.model,
				"data_model": data.value
			};
			if(data.related != undefined){
				code['edge'] = data.related.model;
				code['data_edge'] = data.related.value;
				code['data_relation'] = {
					"CreatedBy":data.username
				};
			}
			console.log("converted added to the ");
			console.log(code);
			if(data.insertRelated == undefined){
				data.insertRelated = false;
			}
			console.log(code);
			Insert_neo4j(code,data.insertRelated,data.username)
			.then(function(res){
				resolve(res);
			})
			.catch(function(e){
				reject(e);
			});
		}else{
			reject(data.message);
		}
	});
}

/**
 * @param {*} code 
 */
function Insert_neo4j(code,overide,username){
	return new Promise((resolve,reject)=>{
		validate_db_query(code)
		.then(function(result){
			console.log("ADD this to Neo4j");
			console.log(result);
			result['data_relation']={"CreatedBy":username};
			ADD(result,overide)
				.then(function(r){
					// Promise.resolve({r,result});
					return {r,result};
				})
				.then(function(res){
					let query = "";
					console.log("this is the");
					console.log(res);
					/** Add Onto the BlueId server */
					if(res.result != undefined && res.result.additionalquery != undefined){
						/** chalo query */
						console.log("additionalquery to run the query");
						result=res.result;
						
						/**
						 * CR 
						 * user assign group will not add lock to the user
						 * event if he is facility-manager
						 */
						if(result.model == "LockGroup"){
							query = `
								match (lg:${result.model}{name:"${result.data_model.name}"})
								match (l:${result.edge}{name:"${result.data_edge.name}"})<-[rl*..3]-(lg)<-[G]-(a:Assistant)<-[ru]-(u:User)-[r]->(D:Device)
								return D.id,l.cylinderId,G.begintime,G.endtime,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype,G.commands
							`;
						}
						// if(result.model == "User"){
						// 	query = `
						// 		match (u:${result.model}{name:"${result.data_model.name}"}) where u.Usertype = "facility-manager"
						// 		match (G:${result.edge}{name:"${result.data_edge.name}"})
						// 		match (D:Device)
						// 		match (l:Lock)
						// 		match (D)<-[r*..3]-(u)
						// 		match (u)-[re*..3]->(G)-[rel*..4]->(l)
						// 		return D.id,l.cylinderId,G.begintime,G.endtime,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype
						// 	`;
						// }else if(result.model == "Group"){
						// 	/**
						// 	 * For facility-manager & for normal user
						// 	 */
						// 	query = `
						// 		match (G:${result.model}{name:"${result.data_model.name}"}) 
						// 		match (n:${result.edge}{name:"${result.data_edge.name}"})
						// 		match (D:Device)
						// 		match (l:Lock)
						// 		match (D)<-[r*..3]-(u) where u.Usertype = "facility-manager"
						// 		match (u)-[re*..3]->(G)-[p]->(n)-[rel]->(l)
						// 		return D.id,l.cylinderId,G.begintime,G.endtime,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype
						// 	`;
						// }else if(result.model == "LockGroup"){
						// 	// match (u)-[rel*..3]->(G)-[re]->(lg)-[rt]->(l)
						// 	query = `
						// 		match (D:Device)<-[r]-(u:User) where u.Usertype = "facility-manager"
						// 		match (l:${result.edge}{name:"${result.data_edge.name}"})<-[rt]-(lg:${result.model}{name:"${result.data_model.name}"})<-[re]-(G:Group)<-[rel*..2]-(u)
						// 		return D.id,l.cylinderId,G.begintime,G.endtime,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype
						// 		union all
						// 		match (D:Device)<-[r]-(u:User) where u.Usertype <> "facility-manager"
						// 		match (l:${result.edge}{name:"${result.data_edge.name}"})<-[rl]-(lg:${result.model}{name:"${result.data_model.name}"})<-[G]-(a:Assistant)<-[ru]-(u)
						// 		return D.id,l.cylinderId,G.begintime,G.endtime,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype
						// 	`;
						// }
							console.log(query);
							if(query == ""){
								resolve(res.r);
							}else{
								console.log(query);
								RUN(query)
								.then(function(s){
									console.log("BlueId connection start :")
									console.log(s);
									return LockRefresh.PUT(s,mode,mysql_connection,username);
								})
								.then(function(s){
									resolve(res.r);
								})
								.catch(function(e){
									reject(e);
								})
							}
						// resolve(res.r);
					}else{
						resolve(res.r);
					}
				})
				.catch(function(e){
					reject(e);
				})
		})
		.catch(function(e){
			reject(e);
		})
	})
}

/**
 * Upload the file
 */
function fileS3Uplaod(result) {
	return new Promise((resolve, reject) => {
	  var buffer = Buffer.from(result.value.file.replace(/^data:image\/\w+;base64,/, ""),"base64");
	  var fileMine = fileType(buffer);
	  console.log(fileMine);
	  if(fileMine === null) {
	   return reject('not a image file')
	  }
	  var params = {
		Bucket: "facilitybook",
		Key: `public/${result.model}`+'/'+Date.now()+'.'+fileMine.ext,
		Body: buffer
	  };
	  if(mode == 'offline') {
		S3.putObject(params.Bucket, params.Key, params.Body, 'image/jpeg', function(err, etag) {
		  if (err) {
			  console.log(err)  
			  reject(err)
		  }
		  else {
			console.log('File uploaded successfully.Tag:',etag) 
			result.value.file = params.bucketname+'/'+params.filename;
			resolve(result)  
		  } 
		});
	  }else{

		S3.putObject(params, function(err, data) {
			if (err) {
				console.log(err)  
				reject(err)
			}
			else {
				console.log('File uploaded successfully.Tag:',data);
				result.value.file = "https://s3.eu-central-1.amazonaws.com/"+params.Bucket+'/'+params.Key;
				resolve(result)  
			}
		});
	  }

	})
  }


/**
 * json
 * last line of code
 */
module.exports={execute};
