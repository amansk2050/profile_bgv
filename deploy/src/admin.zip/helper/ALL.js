/*
1. Generic formula implemented here 
to do queries on neo4j directly
very risky and implement before doing checks
 */

 function DynamicQuery(Neo4j,params){
    return new Promise((resolve,reject)=>{
        /**
         * Now you can send any query to execute on Neo4j with no checks and no schema validation
         */
        console.log(params);
        let offset=20;
        let skip = ( (params.page ||1)-1)*offset;
        var query = "match (n:"+params.model+") return n skip "+skip+" limit "+offset;
        console.log(query);

        Neo4j.cypher({"query":query },function(err,results){
            if(err){
                reject(err);
            }else{
                let sendthis =[];
                results.forEach(element => {
                    sendthis.push(element.n.properties);
                });
                resolve(sendthis);
            }
        })
    })
}

/**
 * 
 * @params
 *         model = "Users"
 *         page =1
 */
 module.exports = function(connector){
    return function(param){
        return DynamicQuery(connector,param);
    }
 }