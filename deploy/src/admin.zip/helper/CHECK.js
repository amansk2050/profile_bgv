/**
 * Neo4j permission check module
 * ASK Mulitple Permission to do check
 */
/**
 * Module level access
 * DB operation access
 */

/**
 * 
 * @param {*} Neo4j 
 * @param {*} param 
 *      contains User <id,name>
 *      contains level: 
 *              id: Projects
 *              params: <id,name> 
 * list of Module or Project or any Company Management Module <>
 */
function Module2(Neo4j,param,json){
    return new Promise((resolve,reject)=>{
        if(param.level2id != undefined){
            let query = `Match (v1:User{name:{UserName}})
            Match (v2:${param.levelid} {name:{levelName}})
            Match (v3:${param.level2id} {name:{level2Name}})
            optional Match p=(v1)-[r*..3]->(v2)
            optional Match q=(v1)-[r*..3]->(v3)
            return nodes(p) AS p1,nodes(q) AS p2
            `;
            console.log(query,param);
            Neo4j.cypher({
                "query":query,
                "params": param
            },function(err,data){
                console.log(err,data);
                if(err){
                    reject(err);
                }else{
                    console.log(JSON.stringify(data,null,6));
                    if(data[0] == undefined){
                        json["allow"]=0,
                        json['message']="NO ACCESS";
                        resolve(json);
                    }
                    allow = 1;
                    data.forEach(element => {
                        content = element;
                        
                        if(content.p1 != undefined ){
                            if(content.p1[0] == undefined){
                                allow=0;
                            }
                        }else{
                            allow =0;
                        }
                        if(content.p2 != undefined ){
                            if(content.p2[0] == undefined){
                                allow = 0;
                            }
                        }else{
                            allow = 0;
                        }
                    });
                    if(allow == 0){
                        json["allow"]=0,
                        json['message']="NO ACCESS";
                        resolve(json);
                    }else{
                        json["allow"]=1,
                        json['message']="HAVE ACCESS";
                        resolve(json);
                    }
                }
            });

        }else{
            console.log("This is for tree stucture of Project");
            let query = `Match (v1:User {name:{UserName}})
            Match (v2:${param.levelid} {name:{levelName}})
            optional Match p=(v1)-[r*..8]->(v2)
            optional match w=(v2)-[t]->(ii)
		    optional Match q=(v2)-[r2*..5]->(n) ,z = (v1)-[r3*..5]->(n)
            return collect(DISTINCT nodes(w)[1]) AS INSIDE,collect(DISTINCT nodes(q)[1]) AS HALF,collect(DISTINCT nodes(p)[1]) AS FULL
            `;
            console.log(query,param);
            Neo4j.cypher({
                "query":query,
                "params":param
            },function(err,data){
                console.log(err,data);
                if(err){
                    reject(err)
                }else{
                    let errcode =0;
                    let result={};

                    console.log(JSON.stringify(data,null,6));
                    if(data[0].FULL[0] != undefined){
                        /**partial access */
                        errcode =1;
                        data[0].INSIDE.forEach((ele)=>{
                            result[ele.labels[0]+":"+ele._id]=ele.properties;
                        });
                    }else if(data[0].HALF[0] != undefined){
                        errcode=0.5;
                        /**full access */
                        data[0].HALF.forEach((ele)=>{
                            result[ele.labels[0]+":"+ele._id]=ele.properties;
                        });
                    }else{
                        errcode = 0;
                        /**no access */
                        data[0].FULL.forEach((ele)=>{
                            result[ele.labels[0]+":"+ele._id] = ele.properties;
                        });
                    }
                    // data.forEach(element => {
                    //     content = element;
                        
                    //     if(content.FULL != undefined && content.FULL.properties){
                    //         errcode=1;
                    //         result[content.INSIDE.labels[0]+":"+content.INSIDE._id]=(content.INSIDE.properties);
                    //     }
                    //     if(content.HALF != undefined && content.HALF.properties){
                    //         errcode=0.5;
                    //         result[content.HALF.labels[0]+":"+content.HALF._id]=(content.HALF.properties);
                    //     }
                    // });
                    console.log(result);
                    if(errcode == 0){
                        reject("No result found");
                    }else if(errcode == 1){
                            json["allow"]=1,
                            json['message']="ALLOW ACCESS";
                            json["reference"]=(result)
                        
                            resolve(json);
                    }else{
                        json["allow"]=0.5,
                        json['message']="PARTIAL ACCESS";
                        json["reference"]=(result);
                        resolve(json);
                    }
                    reject("Something went wrong");
                }
            });
        }
    });
}

module.exports = function(connector){
    return function Module(param,json){
        return Module2(connector,param,json)
    }
}

/**
  * @param {*} Neo4j Neo4j is the DB access
  * @param {*} param 
  *     contains user:User
  *     contains level:(list of Node to access)
  *     contains CRUD operations
  */
// function DB_Operation(Neo4j,param){
//     return new Promise((resolve,reject)=>{
//         /** any path followed by the Permission if yes that user can acess that patter otherwise No */
//         let query = `
//         Match (u1:User{User})
//         Match (v2:${level.id}{level.params})
//         match (u1)-[r*..8]->(m)
//         retun u1,m
//         `;
//         Neo4j.cypher({
//             "query":query,
//             "params":param
//         },function(err,data){
//             console.log(err,data);
//             if(err){
//                 reject(err)
//             }else{
//                 resolve(data);
//             }
//         })
//     })
// }

// module.exports = function(connector){
//     return{
//         "Module": Module(connector,param),
//         "DB_Operation": DB_Operation(connector,param)
//     }
// }
