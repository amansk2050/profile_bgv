const mysqlquery 		= require('../lib/mysql');

function UPDATE(connector,code,change,username,mysql_connection){
    console.log("this is code",code,username);
    return new Promise((resolve,reject)=>{
    // match (n:Projects{Name:"Hochform"}) set n.Name = "2322" return n;
            /**
             * code sample format
             * {
             * 	"model":"Company",
             * "data_model":{
             * 		"Name":"asd",
             * 		"CreatedAt":"pro"
             * 	},
             * // optional here
             * 	"edge":"Projects",	
             * 	"data_relation":{
             * 		"blah":"asd"
             * },
             * "data_edge":{
            * 		"some":"asd"
            * }
            */
        /**
         * change 
         */
        query = '';
        console.log(code.model,code.data_model,change);
        if(code.model && code.data_model && change){
            query += `match (n:${code.model}{name:"${code.data_model.name}"}) `;
            query += `match (s:Log{Name:"CreateAt"}) `
            query += `set n+= {change} `
            query += `set s.time=${new Date().getTime()} `
            query += `return n`
        }else{
            reject("Nothing to change");
        }
        let params={
            query: query,
            params: {change}
        };
        if(query[0] == undefined){
            reject("No query to Process")
        }
        console.log(params);
        var Log = mysqlquery("UPDATE",mysql_connection,username,code.model,code.data_model.name,code.model,code.data_model.name,query,change);

        connector.cypher(params,function(err,result){
            console.log(err,result);
            if(err){
                reject(err)
            }else{
                // if(result[0])
                let content = {};
                if(result[0] != undefined){
                    content.data = result;
                    content['message'] = "Successfully inserted";
                    resolve(content);
                }else{
                    reject("Failed to update");
                }
            }
		});
    })
}

module.exports = function(connector,mysql_connection){
    return function(param,change,data){
        return UPDATE(connector,param,change,data,mysql_connection);
    }
}