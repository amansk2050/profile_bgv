function Run(connector,param){
    return new Promise((resolve,reject)=>{
        connector.cypher({query:param},function(err,data){
            if(err){
                reject(err);
            }
            resolve(data);
        })
    });
}

module.exports = function(connector,mysql_connection){
    return function(param){
        return Run(connector,param);
    }
}
