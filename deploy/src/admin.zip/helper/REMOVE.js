/**
 * Remove any node from the Neo4j
 * Double check module
 * Create module in a inacive and can be fetched laterw
 */
const mysqlquery 		= require('../lib/mysql');

function Remove(connector,code,username,mysql_connection){
//     match (u:Users{Name:"vinay"})
// optional match (g:Groups{Name:"listHorse"})
// optional match (u)-[r]-(g)
// delete r,u

            /**
			 * code sample format
			 * {
			 * 	"model":"Company",
             * "data_model":{
			 * 		"Name":"asd",
			 * 		"CreatedAt":"pro"
			 * 	},
             * // optional here
			 * 	"edge":"Projects",	
			 * 	"data_relation":{
			 * 		"blah":"asd"
			 * },
			 * "data_edge":{
			* 		"some":"asd"
			* }
            */
    return new Promise((resolve,reject)=>{
        if(code.model != undefined){
            let query = "";
            if(code.edge != undefined){
                /**remove the relationship */
				query =`match (u:${code.model}{name:"${code.data_model.name}"}) where NOT EXISTS(u.Usertype) OR NOT u.Usertype IN ["Supersuperadmin"] `;
				query += `match (s:Log{Name:"CreateAt"}) `
                query += `optional match (g:${code.edge}{name:"${code.data_edge.name}"}) `;
				query += `optional match (u)-[r${code.relate}]->(g) `;
				query += `set s.time=${new Date().getTime()} `;
				query += 'delete r';
				try{
				var Log = mysqlquery(
					"REMOVE",
					mysql_connection,
					code.data_relation.CreatedBy,
					code.model,
					code.data_model.name,
					code.edge,
					code.data_edge.name,
					query,
					{}
					).catch(function(e){
					console.log(e);
				});
			}catch(e){
				console.log(e);
			}
            }else{
                /**remove the relation ship + nodes */
                query =`match (u:${code.model}{name:"${code.data_model.name}"}) where NOT EXISTS(u.Usertype) OR NOT u.Usertype IN ["Supersuperadmin"] `;
				query += `match (s:Log{Name:"CreateAt"}) set s.time=${new Date().getTime()} `
				query += `DETACH DELETE u `;
				query += `return count(u) as data`;
				try{
				var Log = mysqlquery(
					"REMOVE",
					mysql_connection,
					username,
					code.model,
					code.data_model.name,
					code.model,
					code.data_model.name,
					query,
					{}).catch(function(e){ 
					console.log(e);
				});
			}catch(e){
				console.log(e);
			}
			}
			
            let params={
				query: query,
				params:{}
			};
			if(query[0] == undefined){
				reject("No query to Process")
			}
			console.log("this query to delete the node");
			console.log(params.query);
            connector.cypher(params,function(err,result){
				console.log(err,result);
				/**
				 * need to apply the case check for the supersuperadmin
				 */
					if(err){
						reject(err)
					}
					if(code.model == "User" && code.edge == undefined && ( result[0].data == "0" || result[0].data == 0) ){
						/**we are removeing the user */
						reject("No able to remove Supersuperadmin");
					}else{
						let content = {};
						content['message'] = "Successfully removed";
						resolve(content);
					}
					// let content = {};
					// if(result[0] != undefined){
					// 	content.data = result;
					// 	content['message'] = "Successfully inserted";
					// 	resolve(content);
					// }else{
					// 	reject("Failed to insert");
					// }
				});
        }else{
            reject("No Model found");
        }
    });
}

module.exports = function(connector,mysql_connection){
    return function(param,username){
        return Remove(connector,param,username,mysql_connection)
    }
}
