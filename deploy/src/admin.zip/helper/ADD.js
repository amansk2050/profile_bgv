/*
1. give me certain model
2. give me its attributes

if some relation in them give then too
I will create a node with that relation here

*/
const mysqlquery 		= require('../lib/mysql');
module.exports = function (connector,mysql_connection) {
	// console.log(connector);
	return function(code,overide){
		return new Promise((resolve,reject)=>{
			console.log(code,overide);
			console.log("code and overide here");
			//overide mean create if not exist
			let query=``;
			query = `match (v1:${code.model}{name:"${code.data_model.name}" }) `;
			query += `match (s:Log{Name:"CreateAt"}) `
			if(code.edge != undefined ){
				if(overide == true){
					query += `create (v2:${code.edge}{data_edge}) `;
					query += `create (v1)-[${code.relate}{data_relation}]->(v2) `
				}else{
					query += `match (v2:${code.edge}{name:"${code.data_edge.name}" }) `;
					query += `merge (v1)-[r${code.relate}]->(v2) `;
					query += `set r.CreatedBy = "${code.data_relation.CreatedBy}" `
				}
				query += `set s.time=${new Date().getTime()} `;
				query += `return v1,v2`;

				var log=mysqlquery("ADD",mysql_connection,code.data_relation.CreatedBy,code.model,code.data_model.name,code.edge,code.data_edge.name,query,code);

			}else{
				if(overide != undefined){
					/**create query to create model */
					query = `match (s:Log{Name:"CreateAt"}) `
					query += `create (v1:${code.model}{data_model}) `;
				}
				query += `set s.time=${new Date().getTime()} `;
				query += 'return v1';
				// no query modified
				var log=mysqlquery("ADD",mysql_connection,code.data_relation.CreatedBy,code.model,code.data_model.name,code.model,code.data_model.name,query,code);
			}
			let params={
				query: query,
				params:code
			};
			if(query[0] == undefined){
				reject("No query to Process");
			}
			console.log(params);
			
			connector.cypher(params,function(err,result){
				console.log(err,result);
					if(err){
						reject(err)
					}else{
						// if(result[0])
						let content = {};
						console.log("done");
						if(result[0] != undefined){
							content.data = result;
							content['message'] = "Successfully inserted";
							resolve(content);
						}else{
							reject("Failed to insert");
						}
					}
				});
				/**
			 * code sample format
			 * {
			 * 	"model":"Company",
			 * 	"edge":"Projects",
			 * 	"data_model":{
			 * 		"Name":"asd",
			 * 		"CreatedAt":"pro"
			 * 	},
			 * 	"data_relation":{
			 * 		"blah":"asd"
			 * },
			 * "data_edge":{
			* 		"some":"asd"
			* }
			*/
			
			/** get connection from the neo4j do the query and give the response */

			//for any object addiion on the neo4j
		//for any array with realtion on the neo4j
		})
	}
}