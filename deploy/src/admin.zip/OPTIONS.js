///// ...................................... start default setup ............................................////
let mode,sns,dynamodb,docClient,S3,neo4j;
const AWS 			= require('aws-sdk');
const response 	= require('./lib/response.js');
const database 	= require('./lib/database.js');

if(process.env.AWS_REGION == "local"){
	mode 				= "offline";
	sns 				= require('../../../offline/sns');
	neo4j		= require('../../../offline/Neo4j');
	docClient 	= require('../../../offline/dynamodb').docClient;
	S3 					= require('../../../offline/S3');
	// dynamodb = require('../../../offline/dynamodb').dynamodb;
}else{
	mode 				= "online";
	sns 				= new AWS.SNS();
	docClient 			= new AWS.DynamoDB.DocumentClient({});
	S3 					= new AWS.S3();
	neo4j 				= require('./lib/neo4j');
	// dynamodb = new AWS.DynamoDB();
}
///// ...................................... end default setup ............................................////

//modules defined here
// const uuid 		= require('uuid');
//call another lambda
// const execute_lambda = require('./lib/lambda')('sample2');
const Ajv 			= require('ajv');
const setupAsync 	= require('ajv-async');
const ajv 			= setupAsync(new Ajv);
const ALL 			= require('./helper/ALL')(neo4j);
const Run 			= require('./helper/RUN')(neo4j);
const authorization = require("./lib/authorization.js");

const ListSchema = {
  "$async":true,
  "type":"object",
  "required":["list"],
  "properties":{
	"list":{"type":"string"},
	"connected":{"type":"string"},
	"User":{"type":"string"},
    "LastEvaluatedKey":{
      "type":"object",
      "additionalProperties": false,
      "properties":{
        "page":{"type":"number"}
      }
    }
  }
};

const validate = ajv.compile(ListSchema);
const offset 	= 20;
/**
 * This is the Promise caller which will call each and every function based
 * @param  {[type]}   data     [content to manipulate the data]
 * @param  {Function} callback [need to send response with]
 * @return {[type]}            [description]
 */
function execute(data,callback){
	let body = data.body;
	let headers = data.headers;

	if(typeof body == "string"){
		try{
			body = JSON.parse(body);
		}catch(e){
			console.log(e);
		}
	}
	validate_all(validate,body)
		.then(function(result){
			return authorization(headers.Authorization,result);
		})
		.then(function(result){
			if(result.connected == "false" || result.connected == undefined ){
				/**
				 * list of all list can be viewed by louis.litt or superadmin
				 */
				//return UserListNodes(result);
				 return getALL(result);
			}else if(result.connected !== "true" ){
				/**
				 * list: Group
				 * connected: Group
				 * lastEvaluatedKey: page: 1
				 */
				return UserListNodes(result);
			}else{
				if(result.User){
					/**
					 * list: User
					 */
					result.username = result.User;
					return UserAdjacientConnectedNodes(result);
				}else{
					/**
					 * list : User
					 * User: value
					 * connected: true
					 * lastEvaluagtedKey
					 */
					return Getconnected(result);
				}
			}
		})
		.then(function(result){
				response({code:200,body:result},callback);
		})
		.catch(function(err){
			if(mode == "online"){
				response({code:400,err:{err}},callback);
			}else{
				response({code:200,err:{err}},callback);
			}
			// response({code:400,err:{err}},callback);
			/**for developement pu */
		})
}

/**
 * validate the data to the categories
 * @param  {[type]} data [description]
 * @return {[type]}      [description]
 */
function validate_all (validate,data) {
	return new Promise((resolve,reject)=>{
		validate(data).then(function (res) {
			console.log(res);
		    resolve(res);
		}).catch(function(err){
		  console.log(JSON.stringify( err,null,6) );
		  reject(err.errors[0].dataPath+" "+err.errors[0].message);
		})
	})
}

/**
 * Permissioncheck
 */
function getALL(result){
	return new Promise((resolve,reject)=>{
		let code={
			"model":result.list,
			"page": result.LastEvaluatedKey.page
		};
		ALL(code)
		.then(function(r){
			resolve(r);
		})
		.catch(function(e){
			reject(e);
		})
	})
}
/**
 * get connected nodes
 */
function Getconnected(result){
	let arr={};
	return new Promise((resolve,reject)=>{
		var query = `
			Match (u:User{name:"${result.username}"})
			Match (p:${result.list}{name:"${result[result.list]}"})
			match (p)-[y]->(k)
			return DISTINCT k,y
			`;
			console.log(query);
			Run(query)
			.then(function(r){
				r.forEach(element => {
					arr[element.k.labels[0]+":"+element.k._id]=Object.assign({},element.k.properties,element.y.properties);
				});
				resolve(arr);
			})
			.catch(function(e){
				reject(e);
			})
	})
}

/**
 * get User connected first node
 */
function UserAdjacientConnectedNodes(result){
	let arr={};
	return new Promise((resolve,reject)=>{
		var query = `
			Match (u:User{name:"${result.username}"})
			Match (k)
			match (u)-[r]->(k)
			return k,r,"" as a
			UNION ALL
			match (u:User{name:"${result.username}"})
			match (u)-[r1]-(a:Assistant)-[r]->(k)
			return k,r,a
			`;
			console.log(query);
			Run(query)
			.then(function(r){
				console.log(JSON.stringify(r,null,5));
				
				r.forEach(element => {
					// arr.push(element.k.properties);
					// element = element.k;
					if(element.a && element.a.properties && element.a.properties.name){
						Object.assign(element.k.properties,{"Assistant":element.a.properties.name});
					}
					arr[element.k.labels[0]+":"+element.k._id]=Object.assign({},element.k.properties,element.r.properties);
				});
				resolve(arr);
			})
			.catch(function(e){
				reject(e);
			})
	})
}

/**
 * User connected list of nodes
 */
function UserListNodes(result){
	let arr={};
	return new Promise((resolve,reject)=>{
		/** all if user is superadmin*/
		if(result.connected == "User"){
			/** superadmin & admin */
			var query = `
				match (u:User{name:"${result.username}"}) where u.Usertype = "superadmin" OR u.Usertype = "Supersuperadmin"
				match (k:User)
				return DISTINCT k skip ${(result.LastEvaluatedKey.page-1)*offset} limit ${offset}
				UNION ALL
				match (u:User{name:"${result.username}"}) where u.Usertype = "admin" OR u.Usertype = "both"
				match (k:User) where k.Usertype <> "superadmin" AND k.Usertype <> "Supersuperadmin"
				match (u)-[r]-(y:Group)<-[l]-(k:User)
				return DISTINCT k skip ${(result.LastEvaluatedKey.page-1)*offset} limit ${offset}
			`;
		}else{
			var query = `
				match (u:User{name:"${result.username}"}) where u.Usertype = "superadmin" OR u.Usertype = "Supersuperadmin"
				match (k:${result.connected})
				return DISTINCT k skip ${(result.LastEvaluatedKey.page-1)*offset} limit ${offset}
				UNION ALL
				match (u:User{name:"${result.username}"}) where u.Usertype = "admin" OR u.Usertype = "both"
				match (k:${result.connected})
				match (u)-[r*..8]->(k)
				return DISTINCT k skip ${(result.LastEvaluatedKey.page-1)*offset} limit ${offset}
			`;
		}
		console.log(query);
		Run(query)
		.then(function(r){
			console.log(JSON.stringify(r,null,5));
			let sendthis =[];
                r.forEach(element => {
                    sendthis.push(element.k.properties);
                });
                resolve(sendthis);
			// r.forEach(element => {
			// 	// arr.push(element.k.properties);
			// 	// element = element.k;
				
			// 	arr[element.k.labels[0]+":"+element.k._id]=(element.k.properties);
			// });
			// resolve(arr);
		})
		.catch(function(e){
			reject(e);
		})
	})
}

/**
 * json schema
 */
module.exports={execute};
