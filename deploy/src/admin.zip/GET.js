///// ...................................... start default setup ............................................////
let mode,sns,dynamodb,docClient,S3,neo4j,mysql_conf;
const AWS 		= require('aws-sdk');
const response 	= require('./lib/response.js');
const database 	= require('./lib/database.js');

if(process.env.AWS_REGION == "local"){
	mode 		= "offline";
	neo4j		= require('../../../offline/Neo4j');
	sns 		= require('../../../offline/sns');
	docClient 	= require('../../../offline/dynamodb').docClient;
	S3 			= require('../../../offline/S3');
	mysql_conf  = require('../../../offline/mysql').Mysql["dev-conf"];
	// dynamodb = require('../../../offline/dynamodb').dynamodb;
}else{
	mode 		= "online";
	sns 		= new AWS.SNS();
	docClient 	= new AWS.DynamoDB.DocumentClient({});
	S3 			= new AWS.S3();
	neo4j 		= require('./lib/neo4j');
	// dynamodb = new AWS.DynamoDB();
	mysql_conf  = database.Mysql["prod-conf"];
}
///// ........................................mysql setup..................................................////

const mysql      = require('mysql');
var mysql_connection;
if(typeof mysql_connection === 'undefined') {
	mysql_connection = mysql.createConnection({
		host            : mysql_conf.host,
		user            : mysql_conf.user,
		password        : mysql_conf.password,
		database        : mysql_conf.database
	});
}

///// ...................................... end default setup ............................................////
const uuid 		= require('uuid');
//call another lambda
// const execute_lambda = require('./lib/lambda')('sample2');
const Ajv 			= require('ajv');
const setupAsync 	= require('ajv-async');
const ajv 			= setupAsync(new Ajv);
const authorization = require("./lib/authorization.js");
const ALL 			= require('./helper/ALL');

const getSchema = {
  "$async":true,
  "type":"object",
  "required":["permission","type"],
  "properties":{
	"permission":{"type":"string"},
	"type":{"type":"string"}
  }
};

// console.log(neo4j);
const validate 					= ajv.compile(getSchema);

const validate_db_query 		= require('./helper/model_validator.js');
const CHECK 					= require('./helper/CHECK')(neo4j);

/**
 * This is the Promise caller which will call each and every function based
 * @param  {[type]}   data     [content to manipulate the data]
 * @param  {Function} callback [need to send response with]
 * @return {[type]}            [description]
 */
function execute(data,callback){
	
	/**
	 * Process
	 * 1. take userid from Authorization token
	 * 2. take Permission uuid from query 
	 * and check for access or not
	 */
	let query = data.query;
	let headers = data.headers;
	validate(data.query)
	.then(function(result){
		return authorization(headers.Authorization,result);
	})
	.then(function(result){
		let Db_values = {};
		Db_values={
			"UserName": result.username,
			"levelid":result.type,
			"levelName":result.permission
		};
		return Db_values;
	})
	.then(function(result){
		return CHECK(result,{})
	})
	.then(function(result){
		response({"code":200,"body":result},callback);
	})
	.catch(function(e){
		console.log(e);
		if(e.message){
			e = e.message;
		};
		response({"code":400,"err":{"err":e}},callback);
	})

	// console.log(neo4j);
	// var data={
	// 	"model":"Projects",
	// 	"edge":"Modules",
	// 	"data_model":{
	// 		"Name":"asd",
	// 		"CreatedAt":"pro"
	// 	},
	// 	"data_relation":{
	// 	},
	// 	"data_edge":{
	// 		"Name":"asd",
	// 		"CreatedAt":"asdasdsd"
	// 	}
	// };
	// validate_db_query(data).then(function(r){
	// 	console.log(r)
	// 	return ADD(r,false);
	// }).catch(function(e){
	// 	console.log(e);
	// })
}

/**
 * last line of code
 * @type {Object}
 */
module.exports={execute};
