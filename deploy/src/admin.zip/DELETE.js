///// ...................................... start default setup ............................................////
let mode,sns,dynamodb,docClient,S3,neo4j;
const AWS 		= require('aws-sdk');
const response 	= require('./lib/response.js');
const database 	= require('./lib/database.js');
const cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();

if(process.env.AWS_REGION == "local"){
	mode 		= "offline";
	sns 		= require('../../../offline/sns');
	neo4j		= require('../../../offline/Neo4j');
	docClient 	= require('../../../offline/dynamodb').docClient;
	S3 			= require('../../../offline/S3');
	// dynamodb = require('../../../offline/dynamodb').dynamodb;
	mysql_conf  = require('../../../offline/mysql').Mysql["dev-conf"];
}else{
	mode 		= "online";
	sns 		= new AWS.SNS();
	docClient 	= new AWS.DynamoDB.DocumentClient({});
	S3 			= new AWS.S3();
	neo4j 		= require('./lib/neo4j');
	// dynamodb = new AWS.DynamoDB();
	mysql_conf  = database.Mysql["prod-conf"];
}
///// ........................................mysql setup..................................................////

const mysql      = require('mysql');
var mysql_connection;

///// ...................................... end default setup ............................................////

//modules defined here
const uuid 		= require('uuid');
//call another lambda
// const execute_lambda = require('./lib/lambda')('sample2');
const Ajv 				= require('ajv');
const setupAsync 		= require('ajv-async');
const ajv 				= setupAsync(new Ajv);
const authorization 	= require("./lib/authorization.js");

const validate_db_query 	= require('./helper/model_validator.js');
const CHECK 				= require('./helper/CHECK.js')(neo4j);
const Remove 				= require('./helper/REMOVE.js')(neo4j,mysql_connection);
const RUN 					= require('./helper/RUN.js')(neo4j,mysql_connection);
const LockRefresh 			= require('./lib/LockRefresh.js');

const deleteSchema = {
	"$async":true,
	"type":"object",
	"required":["model","value"],
	"properties":{
		"model":{"type":"string"},
		"value":{"type":"object"},
		"related":{
			"type":"object",
			"required":["model","value"],
			"properties":{
				"model":{"type":"string"},
				"value":{"type":"object"}
			}
		},
		"insertRelated":{
			"type":"boolean"
		}
	}
};

const validate = ajv.compile(deleteSchema);

/**
 * This is the Promise caller which will call each and every function based
 * @param  {[type]}   data     [content to manipulate the data]
 * @param  {Function} callback [need to send response with]
 * @return {[type]}            [description]
 */
function execute(data,callback){
	/**mysql error queue resolved */
	if(typeof mysql_connection === 'undefined') {
		mysql_connection = mysql.createConnection({
			host            : mysql_conf.host,
			user            : mysql_conf.user,
			password        : mysql_conf.password,
			database        : mysql_conf.database
		});
	}

	if(typeof data.body == "string"){
		data.body = JSON.parse(data.body);
	}
	let body = data.body;
	let headers = data.headers;
	let userpool,username;
	if(body.value.userpool || body.value.username){
		userpool = body.value.userpool;
		username = body.value.username;
		delete body.value.username;
		delete body.value.userpool;
	}
	validate_all(validate,body)
		.then(function(result){
			return authorization(headers.Authorization,result);
		})
		.then(function(result){
			/** check to insert in the model Permission */
			return check_Permission_validation(result);
		})
		.then(function(result){
			console.log("Check permission",result.Db_values);
			console.log(result);
			return CHECK(result.Db_values,result);
		})
		.then(function(result){
			console.log("Remove from neo4j");
			console.log(result);
			return Remove_from_neo4j(result);
		})
		.then(function(result){
			console.log(result);
			if(result.model == "User" && result.edge == undefined){
				console.log("Remove from cognito",username);
				return cognito_remove_user({"username":username,"userpool":userpool});
			}else{
				return result;
			}
		})
		.then(function(result){
			console.log(result);
			response({code:200,body:result},callback);
		})
		.catch(function(err){
			console.log(err);
			if(err.message){
				err = err.message;
			};
			response({code:400,err:{err}},callback);
		})
}

/**
 * 
 * @param {*} data 
 */
function check_Permission_validation(data){
	return new Promise((resolve,reject)=>{
		/** convert header to username */
		let Db_values={};
		if(data.related !== undefined){
			if(data.related.model !== undefined && data.related.value !== undefined){
				Db_values={
					"UserName": data.username,
					"levelid":"Permissions",
					"levelName":"A:"+data.related.model
				};
				data['Db_values']=Db_values;
				resolve(data);
			}else{
				reject("Nothing to check");
			}
		}else{
			//add only model and values check for the schema for validation
			if(data.model){
				Db_values={
					"UserName":data.username,
					"levelid":"Permissions",
					"levelName":"D:"+data.model
				};
				data['Db_values']=Db_values;
				resolve(data);
			}else{
				reject("Permission check failed");
			}
		}
	});
}


/**
 * validate the data to the categories
 * @param  {[type]} data [description]
 * @return {[type]}      [description]
 */
function validate_all (validate,data) {
	return new Promise((resolve,reject)=>{
		validate(data).then(function (res) {
			console.log(res);
		    resolve(res);
		}).catch(function(err){
		  console.log(JSON.stringify( err,null,6) );
		  reject(err.errors[0].dataPath+" "+err.errors[0].message);
		})
	})
}

function Remove_from_neo4j(data){
	/**remove the realtionship and the Node */
	console.log(data);
	let code = {
		"model": data.model,
		"data_model": data.value
	};
	if(data.related != undefined){
		code['edge'] = data.related.model;
		code['data_edge'] = data.related.value;
		code['data_relation']={
			"CreatedBy": data.username
		};
	}
	console.log("code to be executed");
	console.log(code);
	// console.log(Remove());
	// return Remove(code);
	return new Promise((resolve,reject)=>{
		let storeOld=[];
		validate_db_query(code)
		.then(function(r){
			console.log("validated data",r);
			console.log(r);
			/**take the lock and device set before delete */
			return LockAndDevice(r,"BeforeDelete",r);
		})
		.then(function(r){
			console.log("Before the remove",r);
			let old = {};
			// console.log(r)
			 Remove(r,data.username)
				.then(function(res){
					console.log("removed data res",res);
					r['Remove_from_neo4j']=res;
					old = res;
					console.log(old);
					return {r,code};
				})
				.then(function(res){
					console.log("after removed ",res);
					// console.log("after the remove",res);
					// console.log(r);
					// console.log(res);
					/** we need to do the blue id here */
					if(res.r != undefined && res.r.additionalquery != undefined){
						// res.code have the code which we are gonna use to do the operation
						/**so relation only break which is also the main issue */
						let result = res.r;
						return LockAndDevice(result,"AfterDelete",res)
					}else{
						resolve(res.r);
					}
				})
				.then(function(s){
					console.log("comparing before and after",s);
					if(s){
						values = TwoArrayBetween(s.r.BeforeDelete,s.AfterDelete);
						if(values){
							return LockRefresh.DELETE(values,mode,mysql_connection,data.username);
						}else{
							return s;
						}
					}else{
						return s;
					}
				})
				.then(function(a){
					console.log("end result");
					console.log("these are to process",a);
					console.log("old data here",old);
					resolve(old);
				})
				.catch(function(e){
					console.log("Neo4j error",e);
					reject(e);
				})
		})
		.catch(function(e){
			console.log("validation error");
			reject(e);
		})
		// Remove(code)
		// 	.then(function(r){
		// 		console.log(r);
		// 		resolve(r);
		// 	})
		// 	.catch(function(e){
		// 		console.log(e);
		// 		reject(e);
		// 	})
	});
}

function cognito_remove_user(result){
	return new Promise((resolve,reject)=>{
		var params = {
			UserPoolId: result.userpool,
			Username: result.username
		  };
		  cognitoidentityserviceprovider.adminDeleteUser(params, function(err, data) {
				if(err){
					reject(err);
				}else{
					let content={};
					content['message']="Successfully Deleted";
					resolve(content);
				}
		  });
	});
}

/**
 * json
 * last line of code
 */

 /**before Lock */
 function LockAndDevice(r,param,offset){
	 console.log("LockANDDEVICE");
	return new Promise((resolve2,reject2)=>{
		let query = "";
		if(r.additionalquery != undefined){
			if(r.edge == "Lock"){
				/** remove lock from lockgroup */
				query = `
					match (lG:${r.model}{name:"${r.data_model.name}"}) 
					match (l:${r.edge}{name:"${r.data_edge.name}"})
					match (D:Device)<-[r]-(u:User)-[r1]->(a:Assistant)-[G]->(l)
					return D.id,l.cylinderId,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype
					union all
					match (lG:${r.model}{name:"${r.data_model.name}"}) 
					match (l:${r.edge}{name:"${r.data_edge.name}"})
					match (D:Device)<-[r]-(u:User)-[r1]->(a:Assistant)-[G]->(lG)-[r2*..3]->(l)
					return D.id,l.cylinderId,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype
				`;
			}else if(r.edge == "LockGroup"){
				/** remove lockgroup inside there are lockgroup 
				 * CR new lockgroup can have one more lg
				*/
				query = `
					match (lg:${r.model}{name:"${r.data_model.name}"})
					match (lg1:${r.edge}{name:"${r.data_edge.name}"})
					match (l:Lock)
					match (D:Device)<-[r]-(u:User)-[r1]->(a:Assistant)-[G]->(lg)-[r2]->(lg1)-[r3]->(l)
					return D.id,l.cylinderId,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype
					union all
					match (lg:${r.model}{name:"${r.data_model.name}"})
					match (lg1:${r.edge}{name:"${r.data_edge.name}"})
					match (l:Lock)
					match (D:Device)<-[r]-(u:User)-[r1]->(a:Assistant)-[G]->(lg)-[r2]->(lg1)-[r3]>(l)
					return D.id,l.cylinderId,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype
				`;
			}else if(r.model == "User"){
				/** remove user from graph */
				query = `
					match (u:${r.model}{name:"${r.data_model.name}"})
					match (G:${r.edge}{name:"${r.data_edge.name}"})
					match (D:Device)
					match (D)<-[r]-(u)-[r1]->(G)-[r2*..4]->(l:Lock)
					return D.id,l.cylinderId,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype
				`;
			}else if(r.model == "Group"){
				/** remove from group to lockgroup */
				query = `
					match (G:${r.model}{name:"${r.data_model.name}"}) 
					match (lG:${r.edge}{name:"${r.data_edge.name}"}) 
					match (D:Device) 
					match (l:Lock) 
					match (D)<-[r1]-(u)-[r2]->(G)-[r3*..3]->(lG)-[r4]->(l) 
					return D.id,l.cylinderId,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype
				`;
			}else if(r.model == "Assistant"){
				/** remove assistant to lock/lockgroup */
				if(r.edge == "Lock"){
					query = `
						match (a:Assistant{name:"${r.data_model.name}"})
						match (l:Lock{name:"${r.data_edge.name}"})
						match (D:Device)
						match (D)<-[r1]-(u:User)-[r2]-(a)-[G]-(l)
						return D.id,l.cylinderId,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype
					`;
				}else if(r.edge =="LockGroup"){
					query = `
						match (a:Assistant{name:"${r.data_model.name}"})
						match (lg:LockGroup{name:"${r.data_edge.name}"})
						match (D:Device)
						match (D)<-[r1]-(u:User)-[r2]-(a)-[G]-(lg)-[r3*..3]-(l:Lock)
						return D.id,l.cylinderId,u.token,u.tokenActive,u.name,l.name,G.name,u.Usertype
					`;
				}
			}
			console.log("Before All Lock List");
			console.log(query);
			if(query ==""){
				resolve2(offset);
			}else{
				RUN(query)
					.then(function(s){
						offset[param]=s;
						resolve2(offset)
					})
					.catch(function(e){
						reject2(e);
					})
				}
		}else{
			resolve2(r);
		}
	})
}

 function TwoArrayBetween(a,b){
	 console.log("Comparing ARRAY",a,b);
	for(i=0;i<b.length;i++){
		for(j=0;j<a.length;j++){
			if(a[j]['D.id'] == b[i]['D.id'] ){
				a.splice(j,1);
			}
		}
	}
	return a;
 }

module.exports={execute};