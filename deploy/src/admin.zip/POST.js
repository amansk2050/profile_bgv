///// ...................................... start default setup ............................................////
let mode,sns,dynamodb,docClient,S3,neo4j;
const AWS 		= require('aws-sdk');
const response 	= require('./lib/response.js');
const database 	= require('./lib/database.js');

if(process.env.AWS_REGION == "local"){
	mode 		= "offline";
	sns 		= require('../../../offline/sns');
	docClient 	= require('../../../offline/dynamodb').docClient;
	neo4j			= require('../../../offline/Neo4j');
	S3 			= require('../../../offline/S3');
	// dynamodb = require('../../../offline/dynamodb').dynamodb;
	mysql_conf  = require('../../../offline/mysql').Mysql["dev-conf"];
}else{
	mode 		= "online";
	sns 		= new AWS.SNS();
	docClient 	= new AWS.DynamoDB.DocumentClient({});
	S3 			= new AWS.S3();
	neo4j 		= require('./lib/neo4j');
	// dynamodb = new AWS.DynamoDB();
	mysql_conf  = database.Mysql["prod-conf"];
}
///// ........................................mysql setup..................................................////

const mysql      = require('mysql');
var mysql_connection;

///// ...................................... end default setup ............................................////

//modules defined here
const uuid 		= require('uuid');
//call another lambda
// const execute_lambda = require('./lib/lambda')('sample2');
const Ajv 					= require('ajv');
const setupAsync 			= require('ajv-async');
const ajv 					= setupAsync(new Ajv);
const authorization 		= require("./lib/authorization.js");
const fileType      		= require('file-type');

const validate_db_query 				= require('./helper/model_validator.js');
const CHECK 							= require('./helper/CHECK.js')(neo4j,mysql_connection);
const UPDATE 							= require('./helper/UPDATE.js')(neo4j,mysql_connection);
const RUN 								= require('./helper/RUN')(neo4j,mysql_connection);

const updateSchema = {
	"$async":true,
	"type":"object",
	"required":["model","value"],
	"additionalProperties": false,
	"properties":{
		"model":{"type":"string"},
		"value":{"type":"object"},
		"changes":{"type":"object"}
	}
};

const validate = ajv.compile(updateSchema);

/**
 * This is the Promise caller which will call each and every function based
 * @param  {[type]}   data     [content to manipulate the data]
 * @param  {Function} callback [need to send response with]
 * @return {[type]}            [description]
 */
function execute(data,callback){
	if(typeof mysql_connection === 'undefined') {
		mysql_connection = mysql.createConnection({
			host            : mysql_conf.host,
			user            : mysql_conf.user,
			password        : mysql_conf.password,
			database        : mysql_conf.database
		});
	}

	if(typeof data.body == "string"){
		data.body = JSON.parse(data.body);
	}
	let body = data.body;
	let headers = data.headers;
	validate_all(validate,body)
		.then(function(result){
			return authorization(headers.Authorization,result);
		})
		.then(function(result){
			/** if value some base64 text present then switch it to the url */
			if(result.model == "User" || result.model == "LockGroup" || result.model == "Lock"){
				if(result.changes.file){
					return fileS3Uplaod(result);
				}else{
					return result;
				}
			}else{
				return result;
			}
		})
		.then(function(result){
			return check_Permission_validation(result);
		})
		.then(function(result){
			console.log(result);
			return CHECK(result.Db_values,result);
		})
		.then(function(result){
			console.log(result);
			return Update_from_neo4j(result);
		})
		.then(function(result){
			console.log(result);
				response({code:200,body:result},callback);
		})
		.catch(function(err){
			console.log(err);
			response({code:400,err:{err}},callback);
		})
}

/**
 * validate the data to the categories
 * @param  {[type]} data [description]
 * @return {[type]}      [description]
 */
function validate_all (validate,data) {
	return new Promise((resolve,reject)=>{
		validate(data).then(function (res) {
			console.log(res);
		    resolve(res);
		}).catch(function(err){
		  console.log(JSON.stringify( err,null,6) );
		  reject(err.errors[0].dataPath+" "+err.errors[0].message);
		})
	})
}

/**
 * check for permission
 */
function check_Permission_validation(data){
	return new Promise((resolve,reject)=>{
		/** convert header to username */
		let Db_values={};
		if(data.related !== undefined){
			if(data.related.model !== undefined && data.related.value !== undefined){
				//CRUD for create,read ,update,delete
				Db_values={
					"UserName": data.username,
					"levelid":"Permissions",
					"levelName":"U:"+data.related.model
				};
				data['Db_values']=Db_values;
				resolve(data);
			}else{
				reject("Nothing to check"); 
			}
		}else{
			//add only model and values check for the schema for validation
			if(data.model){
				Db_values={
					"UserName":data.username,
					"levelid":"Permissions",
					"levelName":"U:"+data.model
				};
				data['Db_values']=Db_values;
				resolve(data);
			}else{
				reject("Permission check failed");
			}
		}
	})
}

/**
 * @param {*} result 
 */
function Update_from_neo4j(data){
	return new Promise((resolve,reject)=>{
		console.log(data);
		let code = {
			"model": data.model,
			"data_model": data.value
		};
		if(data.related != undefined){
			code['edge'] = data.related.model;
			code['data_edge'] = data.related.value;
			code['data_relation']={
				"CreatedBy": data.username
			};
		}
		console.log(code);
		/**
		 * apply data.changes to check the schema validation
		 */
		let schema_cross_check = Object.assign({},code);
		schema_cross_check["data_model"]=data.changes;

		validate_db_query(schema_cross_check)
		.then(function(rr){
			/** new schema in rr */
			UPDATE(code,data.changes,data.username)
			.then(function(r){
				return {rr,r};
				// Promise.resolve({rr,r});
			})
			.then(function(r){
				/** after addition connected with blueid */
				if(r.rr.additionalquery != undefined){
					resolve(r.r);
				}else{
					resolve(r.r);
				}
			})
			.catch(function(e){
				reject(e);
			})
		})
		.catch(function(e){
			reject(e);
		})

	})
}

/**
 * Upload the file
 */
function fileS3Uplaod(result) {
	return new Promise((resolve, reject) => {
	  var buffer = Buffer.from(result.changes.file.replace(/^data:image\/\w+;base64,/, ""),"base64");
	  var fileMine = fileType(buffer);
	  console.log(fileMine);
	  if(fileMine === null) {
	   return reject('not a image file')
	  }
	  var params = {
		Bucket: "facilitybook",
		Key: `public/${result.model}`+'/'+Date.now()+'.'+fileMine.ext,
		Body: buffer
	  };
	  if(mode == 'offline') {
		S3.putObject(params.Bucket, params.Key, params.Body, 'image/jpeg', function(err, etag) {
		  if (err) {
			  console.log(err)  
			  reject(err)
		  }
		  else {
			console.log('File uploaded successfully.Tag:',etag) 
			result.changes.file = params.bucketname+'/'+params.filename;
			resolve(result)
		  }
		});
	  }else{
		S3.putObject(params, function(err, data) {
			if (err) {
				console.log(err)  
				reject(err)
			}
			else {
				console.log('File uploaded successfully.Tag:',data);
				result.changes.file = "https://s3.eu-central-1.amazonaws.com/"+params.Bucket+'/'+params.Key;
				resolve(result)  
			}
		});
	  }
	  
	})
  }
  
/**
 * JSON schema
 */
module.exports={execute};